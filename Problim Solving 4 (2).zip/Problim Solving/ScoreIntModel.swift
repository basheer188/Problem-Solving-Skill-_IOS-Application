//
//  ScoreIntModel.swift
//  javaBoi
//
//  Created by SAIL on 30/10/23.
//

import Foundation

// MARK: - Welcome
struct ScoreIntModel: Codable {
    var status: Bool?
    var message: String?
    var data: [ScoreIntModelData]?
}

// MARK: - Datum
struct ScoreIntModelData: Codable {
    var username, intLevel1: String?

    enum CodingKeys: String, CodingKey {
        case username
        case intLevel1 = "int_level1"
    }
}
