//
//  Score2Model.swift
//  javaBoi
//
//  Created by SAIL on 30/10/23.
//

import Foundation

// MARK: - Welcome
struct Score2Model: Codable {
    var status: Bool?
    var message: String?
    var data: [Score2ModelData]?
}

// MARK: - Datum
struct Score2ModelData: Codable {
    var username, quizScore: String?

    enum CodingKeys: String, CodingKey {
        case username
        case quizScore = "quiz_score"
    }
}
