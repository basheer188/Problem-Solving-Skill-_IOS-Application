//
//  ExpertScoreModel.swift
//  javaBoi
//
//  Created by SAIL on 30/10/23.
//

import Foundation

// MARK: - Welcome
struct ExpertScoreModel: Codable {
    var userProgress: [ExpertScore]?
    var status: String?
}

// MARK: - UserProgress
struct ExpertScore: Codable {
    var level1_Points, level2_Points, level3_Points, level4_Points: String?

    enum CodingKeys: String, CodingKey {
        case level1_Points = "level_1_points"
        case level2_Points = "level_2_points"
        case level3_Points = "level_3_points"
        case level4_Points = "level_4_points"
    }
}
