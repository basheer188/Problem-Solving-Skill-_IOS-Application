//
//  LoginModel.swift
//  javaBoi
//
//  Created by SAIL on 13/10/23.
//

import Foundation

// MARK: - Welcome
struct Login: Codable {
    var status: Bool?
    var message: String?
    var data: [LoginData]?
}

// MARK: - Datum
struct LoginData: Codable {
    var userID, username, password: String?

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case username, password
    }
}


