//
//  certificateviewcontroller.swift
//  Problim Solving
//
//  Created by SAIL on 06/10/23.
//

import UIKit

class certificateviewcontroller: UIViewController {
    @IBOutlet weak var backButton: UIImageView!
    @IBOutlet weak var beginnercertificate: UIView!
    @IBOutlet weak var certificate: UILabel!
    @IBOutlet weak var medal: UIImageView!
    @IBOutlet weak var profile: UIImageView!
    @IBOutlet weak var done: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()

        backButton.addAction(for: .tap){
            self.navigationController?.popViewController(animated: true)
        } // Do any additional setup after loading the view.
    }
    
    @IBAction func nextlevelbutton(_ sender: Any) {
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
