//
//  scoreTableViewCell.swift
//  Problim Solving
//
//  Created by SAIL on 25/10/23.
//

import UIKit

class scoreTableViewCell: UITableViewCell {

    @IBOutlet weak var rank: UIImageView!
    @IBOutlet weak var basheer: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
