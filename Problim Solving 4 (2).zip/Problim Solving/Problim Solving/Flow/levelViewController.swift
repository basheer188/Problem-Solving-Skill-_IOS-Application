//
//  levelViewController.swift
//  javaBoi
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class levelViewController: UIViewController {

    @IBOutlet weak var scoreboardbtn: UIImageView!
    
    @IBOutlet weak var profilebtn: UIImageView!
    @IBOutlet weak var backButton: UIImageView!
    @IBOutlet weak var logoutbtn: UIImageView!
    @IBOutlet weak var level2Image: UIImageView!
    @IBOutlet weak var level3Image: UIImageView!
    @IBOutlet weak var level4Image: UIImageView!
    
    @IBOutlet weak var level1bird: UIImageView!
    
    @IBOutlet weak var level2bird: UIImageView!
    
    
    @IBOutlet weak var level3bird: UIImageView!
    
    @IBOutlet weak var level4bird: UIImageView!
    
    @IBOutlet weak var level1: UIImageView!
    
    @IBOutlet weak var go: UIButton!
    
    var beginnerScore: BeginnerScoreModel!
    var intermediateScore: IntermediateScoreModel!
    var ExpertScore: ExpertScoreModel!
    
    override func viewWillAppear(_ animated: Bool) {
        if UserDefaultsManager.shared.getUserCompetency() == "Beginner" {
        getProfileAPI()
    }
        if UserDefaultsManager.shared.getUserCompetency() == "Intermediate" {
        getProfile2API()
    }
        if UserDefaultsManager.shared.getUserCompetency() == "Expert" {
        getProfile3API()
    }
    func getProfileAPI() {
           APIHandler().getAPIValues(type: BeginnerScoreModel.self, apiUrl: ServiceAPI.BeginnerlevelURL, method: "GET") { result in
               switch result {
               case .success(let data):
                   self.beginnerScore = data // Assign the fetched data to the beginnerScoreModel property
                   print(self.beginnerScore?.userProgress ?? "")
                   print(self.beginnerScore?.userProgress?.count ?? 0)
                   DispatchQueue.main.async {
                       if Int(self.beginnerScore.userProgress?.first?.level1_Points ?? "") ?? 0 > 5 {
                           self.level2Image.image = UIImage(named: "unlock 1")
                       }
                       if Int(self.beginnerScore.userProgress?.first?.level2_Points ?? "") ?? 0 > 5 {
                           self.level3Image.image = UIImage(named: "unlock 1")
                       }
                       if Int(self.beginnerScore.userProgress?.first?.level3_Points ?? "") ?? 0 > 5 {
                           self.level4Image.image = UIImage(named: "unlock 1")
                       }
                   }

               case .failure(let error):
                   print(error)
               }
           }
       }

        func getProfile2API() {
               APIHandler().getAPIValues(type: IntermediateScoreModel.self, apiUrl: ServiceAPI.IntermediatelevelURL, method: "GET") { result in
                   switch result {
                   case .success(let data):
                       self.intermediateScore = data // Assign the fetched data to the beginnerScoreModel property
                       print(self.intermediateScore?.userProgress ?? "")
                       print(self.intermediateScore?.userProgress?.count ?? 0)
                       DispatchQueue.main.async {
                           if Int(self.intermediateScore.userProgress?.first?.level1_Points ?? "") ?? 0 > 5 {
                               self.level2Image.image = UIImage(named: "unlock 1")
                           }
                           if Int(self.intermediateScore.userProgress?.first?.level2_Points ?? "") ?? 0 > 5 {
                               self.level3Image.image = UIImage(named: "unlock 1")
                           }
                           if Int(self.intermediateScore.userProgress?.first?.level3_Points ?? "") ?? 0 > 5 {
                               self.level4Image.image = UIImage(named: "unlock 1")
                           }
                       }

                   case .failure(let error):
                       print(error)
                   }
               }
           }
        func getProfile3API() {
               APIHandler().getAPIValues(type: ExpertScoreModel.self, apiUrl: ServiceAPI.ExpertlevelURL, method: "GET") { result in
                   switch result {
                   case .success(let data):
                       self.ExpertScore = data // Assign the fetched data to the beginnerScoreModel property
                       print(self.ExpertScore?.userProgress ?? "")
                       print(self.ExpertScore?.userProgress?.count ?? 0)
                       DispatchQueue.main.async {
                           if Int(self.ExpertScore.userProgress?.first?.level1_Points ?? "") ?? 0 > 5 {
                               self.level2Image.image = UIImage(named: "unlock 1")
                           }
                           if Int(self.ExpertScore.userProgress?.first?.level2_Points ?? "") ?? 0 > 5 {
                               self.level3Image.image = UIImage(named: "unlock 1")
                           }
                           if Int(self.ExpertScore.userProgress?.first?.level3_Points ?? "") ?? 0 > 5 {
                               self.level4Image.image = UIImage(named: "unlock 1")
                           }
                       }

                   case .failure(let error):
                       print(error)
                   }
               }
           }
    }
    override func viewDidLoad() {
           super.viewDidLoad()
        go .isEnabled = false
        
        backButton.addAction(for: .tap){
            self.navigationController?.popViewController(animated: true)
        }
        level2bird.isHidden = true
        level3bird.isHidden = true
        level4bird.isHidden = true
        self.level1.image = UIImage(named: "unlock 1")
        
        scoreboardbtn.addAction(for: .tap){
            let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "overallscoreboardViewController") as! overallscoreboardViewController
            self.navigationController?.pushViewController(signupVC, animated: true)
        }
        
        profilebtn.addAction(for: .tap){
            let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "profileviewcontroller") as! profileviewcontroller
            self.navigationController?.pushViewController(signupVC, animated: true)
        }
        
        logoutbtn.addAction(for: .tap){
            let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "loginViewController") as! loginViewController
            self.navigationController?.pushViewController(signupVC, animated: true)
        }
        
        
        if self.level1.image == UIImage(named: "unlock 1") {
                level1.addAction(for: .tap) {
                    self.go .isEnabled = true
                    UserDefaultsManager.shared.saveUserLevel("1")

                    self.level1bird.isHidden = false
                    self.level2bird.isHidden = true
                    self.level3bird.isHidden = true
                    self.level4bird.isHidden = true
                    
            }
            }
        
         
            level2Image.addAction(for: .tap) {
                self.go .isEnabled = true
                UserDefaultsManager.shared.saveUserLevel("2")
                if self.level2Image.image == UIImage(named: "unlock 1") {
                    
                self.level1bird.isHidden = true
                self.level2bird.isHidden = false
                self.level3bird.isHidden = true
                self.level4bird.isHidden = true
                
        }
        }
    
            level3Image.addAction(for: .tap) {
                self.go .isEnabled = true
                UserDefaultsManager.shared.saveUserLevel("3")
                
                if self.level3Image.image == UIImage(named: "unlock 1") {
                self.level1bird.isHidden = true
                self.level2bird.isHidden = true
                self.level3bird.isHidden = false
                self.level4bird.isHidden = true

        }
        }
       
            level4Image.addAction(for: .tap) {
                self.go .isEnabled = true
                UserDefaultsManager.shared.saveUserLevel("4")
                if self.level4Image.image == UIImage(named: "unlock 1") {
                self.level1bird.isHidden = true
                self.level2bird.isHidden = true
                self.level3bird.isHidden = true
                self.level4bird.isHidden = false

        }
        }
//         Do any additional setup after loading the view.
    }
    

    @IBAction func gobtn(_ sender: Any) {
        let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewController") as! Quizviewcontroller
        self.navigationController?.pushViewController(signupVC, animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}
