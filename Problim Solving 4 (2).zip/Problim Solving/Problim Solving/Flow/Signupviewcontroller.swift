//
//  Signupviewcontroller.swift
//  Problim Solving
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class Signupviewcontroller: UIViewController {
    
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var backButton: UIImageView!
    
    
    @IBOutlet weak var confirmpassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
    
        backButton.addAction(for: .tap){
            self.navigationController?.popViewController(animated: true)
        }
        // Do any additional setup after loading the view.
    }
    
    @IBAction func signupbutton(_ sender: Any) {
        registerUser()
    }
    func registerUser() {
            let formData: [String: String] = [
                "username": username.text ?? "",
                "email": email.text ?? "",
                "password": password.text ?? "",
                "confirmpassword": confirmpassword.text ?? ""
            ]
        if username.text == "" && password.text == "" && email.text=="" && confirmpassword.text==""{
            let alert = UIAlertController(title: "Alert", message: "Textfield is Empty", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            present(alert, animated: true)
        } else {
    
        APIHandler().postAPIValues(type: Signup.self, apiUrl: ServiceAPI.signupUrl, method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status)")
                    print("Message: \(response.message)")
                    DispatchQueue.main.async {
                      let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "loginViewController") as! loginViewController
                        self.navigationController?.pushViewController(nextVC, animated: true)
                    }
                case .failure(let error):
                    print("Error: \(error)")
                }
            }
        }
    }
    
}
