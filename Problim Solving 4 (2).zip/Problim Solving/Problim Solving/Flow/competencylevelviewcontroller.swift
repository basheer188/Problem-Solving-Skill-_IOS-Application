//
//  competencylevelviewcontroller.swift
//  Problim Solving
//
//  Created by SAIL on 06/10/23.
//

//
//  competencyviewcontroller.swift
//  javaBoi
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class competencylevelviewcontroller: UIViewController {

    @IBOutlet weak var scoreboardbtn: UIImageView!
    @IBOutlet weak var profilebtn: UIImageView!
    @IBOutlet weak var logoutbtn: UIImageView!
    /////////
    @IBOutlet weak var backButton: UIImageView!
   ////////
    
    override func viewDidLoad() {
        super.viewDidLoad()
        scoreboardbtn.addAction(for: .tap){
            let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "overallscoreboardViewController") as! overallscoreboardViewController
            self.navigationController?.pushViewController(signupVC, animated: true)
        }
        
        profilebtn.addAction(for: .tap){
            let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "profileviewcontroller") as! profileviewcontroller
            self.navigationController?.pushViewController(signupVC, animated: true)
        }
        
        logoutbtn.addAction(for: .tap){
            let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "loginViewController") as! loginViewController
            self.navigationController?.pushViewController(signupVC, animated: true)
        }
        /////////
        backButton.addAction(for: .tap){
            self.navigationController?.popViewController(animated: true)
        }
        
        self.navigationController?.navigationBar.isHidden = true
   
    }
    

    @IBAction func beginnerbtn(_ sender: Any) {
        UserDefaultsManager.shared.saveUserCompetency("Beginner")
        let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "levelViewController") as! levelViewController
        self.navigationController?.pushViewController(signupVC, animated: true)
    }
    
    
    @IBAction func intermediatebtn(_ sender: Any) {
        UserDefaultsManager.shared.saveUserCompetency("Intermediate")
        let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "levelViewController") as! levelViewController
        self.navigationController?.pushViewController(signupVC, animated: true)
    }
    
    @IBAction func expertbtn(_ sender: Any) {
        UserDefaultsManager.shared.saveUserCompetency("Expert")
        let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "levelViewController") as! levelViewController
        self.navigationController?.pushViewController(signupVC, animated: true)
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
