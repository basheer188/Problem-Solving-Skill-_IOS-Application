//
//  ViewController.swift
//  Problim Solving
//
//  Created by SAIL on 20/09/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var userName: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    
}

