//
//  AchievementModel.swift
//  Problim Solving
//
//  Created by SAIL on 26/12/23.
//

import Foundation

// MARK: - Welcome
struct Achievement: Codable {
    var updateStatus: String?
    var data: [AchievementData]?

    enum CodingKeys: String, CodingKey {
        case updateStatus = "update_status"
        case data = "Data"
    }
}

// MARK: - Datum
struct AchievementData: Codable {
    var beginnerScore, intermediateScore, expertScore: Int?

    enum CodingKeys: String, CodingKey {
        case beginnerScore = "beginner_score"
        case intermediateScore = "intermediate_score"
        case expertScore = "expert_score"
    }
}
